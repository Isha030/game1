







import pygame

pygame.init()
WIDTH = 1920
HEIGHT = 1080
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Whaterfall')
clock = pygame.time.Clock()
FPS = 60

moving_left = False
moving_right = False
shoot = False

# Boden


boden1 = pygame.Rect(234, 670, 320, 3)
boden2 = pygame.Rect(1320, 670, 320, 3)
boden3 = pygame.Rect(780, 540, 320, 3)
boden4 = pygame.Rect(50, 190, 180, 3)

boden5 = pygame.Rect(410, 330, 200, 3)
boden6 = pygame.Rect(1650, 480, 300, 3)




r = (0, 201, 120)
BLACK = (0, 0, 0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)

TILE_SIZE = 2

# variablen fürs spiel
GRAVITY = 0.8

BG = pygame.image.load('hintergrund.png')

def bgUpdate():
    screen.fill(r)
    screen.blit(BG, [0, 0])
    #screen.blit(BG.(0,0))
  #  pygame.draw.line(screen, BLACK, (0, 1000), (WIDTH, 1000))


bullet_img = pygame.image.load('bullet.png').convert_alpha()
hintergrund_img = pygame.image.load('hintergrund.png')

heal_box_img = pygame.image.load('hp2.png').convert_alpha()
ammo_box_img = pygame.image.load('ammor1.png').convert_alpha()

item_boxes = {
    'Health'  : heal_box_img,
    'Ammo'    : ammo_box_img
}
# def fpmt
font = pygame.font.SysFont('Futura', 80)


def draw_text(text, font, text_col, x, y):
    img = font.render(text,True, text_col)
    screen.blit(img, (x,y))

# HELDEN KLASSE MAIN PLAYER
class Held(pygame.sprite.Sprite):
    def __init__(self, charakter, x, y, scale, speed, ammo):
        # basic konstruktor alle meine eigenschaften des helden
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.charakter = charakter
        self.jump = False
        self.in_air = True
        self.speed = speed
        self.start_ammo = ammo
        self.ammo = ammo
        self.shoot_cooldown = 0
        self.health = 100
        self.max_health = self.health
        self.vel_y = 0  # sprung speed
        self.richtung = 1
        self.flip = False
        self.animation_list = []
        self.frame_index = 0
        self.action = 0

        # boden position für kollision
        self.width = 20
        self.height = 145

        self.update_time = pygame.time.get_ticks()

        # bilder animation für den stand
        temp_list = []
        for i in range(5):
            img = pygame.image.load(
                f'{self.charakter}{i}.png')  # hier muss ich noch einen ordner bzw angabe stehen hinzufügen
            img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
            temp_list.append(img)
        self.animation_list.append(temp_list)

        # bilder animation für die bewegung rennen
        temp_list = []
        for i in range(12):
            img = pygame.image.load(
                f'{self.charakter}{i}run.png').convert_alpha()  # hier muss ich noch einen ordner run hinzufügen
            img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
            temp_list.append(img)
        self.animation_list.append(temp_list)
        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def spielupdate(self):
        self.update_animation()
        self.check_alive()
        #shoot cooldown
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1




    def movement(self, moving_left, moving_right):
        dx = 0
        dy = 0
        if moving_left:
            dx = -self.speed
            self.flip = True
            self.richtung = -2

        if moving_right:
            dx = self.speed
            self.flip = False
            self.richtung = 2

        # Springen
        if self.jump == True and self.in_air == False:
            self.vel_y = -21
            self.jump = False
            self.in_air = True

        # Gravity
        self.vel_y += GRAVITY
        if self.vel_y > 20:
            self.vel_y = 20
        dy += self.vel_y

        # kollisions abfrage
        if self.rect.bottom + dy > 900:
            dy = 900 - self.rect.bottom
            self.in_air = False

        # kollision boden 1
        if boden1.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
            dx = 0
            self.in_air = False
        if boden1.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
            dy = 0
            self.in_air = False

        # kollision boden 2
        if boden2.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
            dx = 0
            self.in_air = False
        if boden2.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
            dy = 0
            self.in_air = False

        # kollision boden 3
        if boden3.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
            dx = 0
            self.in_air = False
        if boden3.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
            dy = 0
            self.in_air = False

        # kollision boden 4
        if boden4.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
            dx = 0
            self.in_air = False
        if boden4.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
            dy = 0
            self.in_air = False

        # kollision boden 5
        if boden5.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
            dx = 0
            self.in_air = False
        if boden5.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
            dy = 0
            self.in_air = False

        # kollision boden 6
        if boden1.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
            dx = 0
            self.in_air = False
        if boden1.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
            dy = 0
            self.in_air = False

        self.rect.x += dx
        self.rect.y += dy



    def bodenDraw(self):

        pygame.draw.rect(screen, (BLACK), boden1)
        pygame.draw.rect(screen, (BLACK), boden2)
        pygame.draw.rect(screen, (BLACK), boden3)
        pygame.draw.rect(screen, (BLACK), boden4)
        pygame.draw.rect(screen, (BLACK), boden5)
        pygame.draw.rect(screen, (BLACK), boden6)



    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.speed = 0
            self.alive = False
            self.update_action()

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)

    def update_action(self, new_action):
        # check welche aktion ich benutze ( existiert eine neue aktion)
        if new_action != self.action:
            self.action = new_action
            # update animation
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()



    def shoot(self):
        if self.shoot_cooldown == 0 and self.ammo > 0:
            self.shoot_cooldown = 20
            bullet = Bullet(player.rect.centerx + (0.6 * self.rect.size[0]* self.richtung), self.rect.centery, self.richtung)
            bullet_group.add(bullet)
            self.ammo -= 1



    def update_animation(self):
        # update die animation
        ANIMATION_COOLDOWN = 60
        # abhengigkeit von frame
        self.image = self.animation_list[self.action][self.frame_index]
        #       zeit setzten wann die für die animation
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        # die animation loopen (wenn die animation das letzte bild erreicht geht sie zum ersten bild zurück)
        if self.frame_index >= len(self.animation_list[self.action]):
            self.frame_index = 0



# items klasse
class ItemBox(pygame.sprite.Sprite):
    def __init__(self, item_type, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.item_type = item_type
        self.image = item_boxes[self.item_type]
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        if pygame.sprite.collide_rect(self, player):
            # welche box hat player aufgesammelt
            if self.item_type == 'Health':
                player.health += 25
                if player.health > player.max_health:
                    player.health = player.max_health

            elif self.item_type == 'Ammo':
                player.ammo += 15
            self.kill()

# hp anzeige
class HealthBar():
    def __init__(self, x, y, health, max_health):
        self.x = x
        self.y = y
        self.health = health
        self.max_health = max_health


    def draw(self,health):
        self.health = health
        ratio = self.health / self.max_health
        pygame.draw.rect(screen, BLACK, (self.x-2, self.y-2, 154, 24))
        pygame.draw.rect(screen,RED, (self.x, self.y, 150, 20))
        pygame.draw.rect(screen, GREEN,(self.x, self.y, 150 * ratio, 20))

        pygame.draw.rect(screen, RED, (self.x, self.y, 150, 20))



# Bullet klasse

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, richtung):
        pygame.sprite.Sprite.__init__(self)

        #geschwindigkeit der schüsse
        self.speed = 40
        self.image = bullet_img
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.direction = richtung

    def update(self):
        self.rect.x += (self.direction * self.speed)
        if self.rect.right < 0 or self.rect.left > WIDTH - 200:
            self.kill()

        # kollision mit objekten
        if pygame.sprite.spritecollide(player, bullet_group, False):
            if player.alive:
                player.health -= 5
                self.kill()

        if pygame.sprite.spritecollide(gegner, bullet_group, False):
            if player.alive:
                gegner.health -= 25
                self.kill()
















#-------------------------- Run ---------------------------------------
# create sprite groups

bullet_group = pygame.sprite.Group()
item_box_group = pygame.sprite.Group()


item_box = ItemBox('Health',400,650)
item_box_group.add(item_box)
item_box = ItemBox('Ammo',1600,650)
item_box_group.add(item_box)

# HELD DEFINIERT MIT ALLEN EIGENSCHAFTEN DES KONSTRUKTORS
player = Held('held', 200, 500, 1, 7, 20)
health_bar = HealthBar(30,30, player.health, player.health)

gegner = Held('held', 600, 800, 1, 7, 20)

# MAIN UPDATE WHILE LOOP
run = True
while run:
    clock.tick(FPS)
    bgUpdate()
    player.bodenDraw()

    #player hp anzeige
    health_bar.draw(player.health)

    # show ammo bullets zahl und image
    draw_text(f'AMMO: {player.ammo}', font, WHITE, 10, 115)
    for x in range(player.ammo):
        screen.blit(bullet_img,(20 + (x*13),80))

    player.spielupdate()
    player.draw()
    gegner.draw()
    gegner.update()
    player.movement(moving_left, moving_right)



    # update gruppen
    bullet_group.update()
    bullet_group.draw(screen)
    item_box_group.update()
    item_box_group.draw(screen)

    # update player actions, wenn der spieler am leben ist
    if player.alive:

        if shoot:
            player.shoot()

        # wenn der spier springt soll die animation zum springen eingeblendet werden mit den wert 2
        if player.in_air:
            player.update_action(2)

        # wenn der spieler nach links oder rechts läugt ist die aktion 1
        if moving_left or moving_right:
            player.update_action(1)  # spieler läuft jetzt
        else:
            # wenn der spieler nichts macht dann ist die aktion 0
            player.update_action(0)
        player.movement(moving_left, moving_right)





    # MEINE BEWEGUNGS ABFRAGEN UND KEYSTROKES
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        # EVENT WENN ICH DIE TASTE DRÜCKE
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                moving_left = True
            if event.key == pygame.K_RIGHT:
                moving_right = True

            if event.key == pygame.K_a:
                shoot = True

            if event.key == pygame.K_s and player.alive:
                player.jump = True
            if event.key == pygame.K_ESCAPE:
                run = False

        # EVENT WENN ICH DIE TASTE LOS LASSE
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                moving_left = False
            if event.key == pygame.K_RIGHT:
                moving_right = False
            if event.key == pygame.K_a:
                shoot = False
    # DER PYGAME UPDATE
    pygame.display.update()

pygame.quit()
